<template>
  <div class="card"><slot /></div>
</template>
